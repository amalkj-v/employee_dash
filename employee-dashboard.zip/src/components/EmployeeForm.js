import React, { useState } from 'react';

function EmployeeForm() {
  const [formData, setFormData] = useState({
    name: '',
    designation: '',
    location: '',
    salary: ''
  });

  const handleChange = (e) => {
    setFormData({...formData, [e.target.name]: e.target.value });
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
    alert("Form submitted! Check console for data.");
    setFormData({name:'', designation:'', location:'', salary:''});
  }

  return (
    <div>
      <h2>Employee Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label>Name</label>
          <input type="text" className="form-control" name="name" value={formData.name} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Designation</label>
          <input type="text" className="form-control" name="designation" value={formData.designation} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Location</label>
          <input type="text" className="form-control" name="location" value={formData.location} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Salary</label>
          <input type="number" className="form-control" name="salary" value={formData.salary} onChange={handleChange} required />
        </div>
        <button className="btn btn-primary">Submit</button>
      </form>
    </div>
  );
}

export default EmployeeForm;